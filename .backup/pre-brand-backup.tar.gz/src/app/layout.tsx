import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";

const geistSans = localFont({
  src: "./fonts/Geist-Variable.woff2",
  variable: "--font-geist-sans",
  weight: "100 900",
});

const geistMono = localFont({
  src: "./fonts/GeistMono-Variable.woff2",
  variable: "--font-geist-mono",
  weight: "100 900",
});

import { BRANDING } from "@/config/branding";

export const metadata: Metadata = {
  title: BRANDING.PRODUCT_NAME,
  description: "Deterministic trade stress testing, basis decoupling analysis, and thesis vs position deconstruction."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body className="antialiased font-sans bg-zinc-100/50 text-zinc-900">{children}</body>
    </html>
  );
}


